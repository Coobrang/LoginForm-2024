document.getElementById("forgot-password-link").addEventListener("click", function(event) {
    event.preventDefault();
    
    document.body.classList.add("fade-out");

    setTimeout(function() {
        window.location.href = "forgot-password.html";
    }, 500);
});